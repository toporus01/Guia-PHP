<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedido de Pizzas</title>
</head>
<body>
    <?php
    include 'conexion.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = $_POST['nombre'];
        $direccion = $_POST['direccion'];
        $pedidos = [];

        if (isset($_POST['jamon_queso']) && $_POST['cantidad_jamon_queso'] > 0) {
            $pedidos[] = "Jamón y Queso: " . $_POST['cantidad_jamon_queso'];
        }
        if (isset($_POST['napolitana']) && $_POST['cantidad_napolitana'] > 0) {
            $pedidos[] = "Napolitana: " . $_POST['cantidad_napolitana'];
        }
        if (isset($_POST['muzzarella']) && $_POST['cantidad_muzzarella'] > 0) {
            $pedidos[] = "Muzzarella: " . $_POST['cantidad_muzzarella'];
        }

        $pedido_texto = "Nombre: " . $nombre . "\n";
        $pedido_texto .= "Dirección: " . $direccion . "\n";
        $pedido_texto .= "Pedidos:\n" . implode("\n", $pedidos) . "\n";
        $pedido_texto .= str_repeat('.', 20) . "\n";

        // Guardar en archivo (puedes mantener esto si quieres seguir guardando en el archivo)
        file_put_contents('pedidos.txt', $pedido_texto, FILE_APPEND);
        
        // Insertar en la base de datos
        $ejercicio = 'Pedido de Pizzas';
        $resultado = "Nombre: $nombre, Dirección: $direccion, Pedidos: " . implode(", ", $pedidos);

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<h2>Pedido registrado</h2>";
        echo "<p>Gracias, " . htmlspecialchars($nombre) . ". Su pedido ha sido registrado.</p>";
        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
    ?>
    <h1>Pedido de Pizzas</h1>
    <form method="post" action="">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br><br>
        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" required>
        <br><br>
        <label>Tipo de Pizzas:</label><br>
        <input type="checkbox" id="jamon_queso" name="jamon_queso">
        <label for="jamon_queso">Jamón y Queso</label>
        <input type="number" id="cantidad_jamon_queso" name="cantidad_jamon_queso" min="0" value="0"><br>
        <input type="checkbox" id="napolitana" name="napolitana">
        <label for="napolitana">Napolitana</label>
        <input type="number" id="cantidad_napolitana" name="cantidad_napolitana" min="0" value="0"><br>
        <input type="checkbox" id="muzzarella" name="muzzarella">
        <label for="muzzarella">Muzzarella</label>
        <input type="number" id="cantidad_muzzarella" name="cantidad_muzzarella" min="0" value="0"><br><br>
        <input type="submit" value="Confirmar">
    </form>
    <?php
    }
    ?>
</body>
</html>
