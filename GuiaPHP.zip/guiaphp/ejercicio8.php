<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio PHP</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #1E90FF, #87CEEB); 
        }

        
        .header {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            color: #fff;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); 
        }

        
        .container {
            text-align: center;
            padding: 30px;
            border-radius: 15px;
            background-color: #ffffff;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            width: 350px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .container:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3);
        }

        .fade-in {
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <header class="header fade-in">Guía de Ejercicio PHP</header>
    <div class="container fade-in">

        /*for */
        <?php
            echo "Tabla del 2 usando for:<br>";
            for ($i = 1; $i <= 10; $i++) {
                echo "2 x $i = " . (2 * $i) . "<br>";
            }
        ?>

        /*while*/
        <?php
            echo "<br>Tabla del 2 usando while:<br>";
            $i = 1;
            while ($i <= 10) {
                echo "2 x $i = " . (2 * $i) . "<br>";
                $i++;
            }
        ?>

        /*do/while */
        <?php
            echo "<br>Tabla del 2 usando do/while:<br>";
            $i = 1;
            do {
                echo "2 x $i = " . (2 * $i) . "<br>";
                $i++;
            } while ($i <= 10);
        ?>
    </div>
</body>
</html>









