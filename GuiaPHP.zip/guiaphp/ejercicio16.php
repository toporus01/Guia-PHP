<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Pedidos de Pizzas</title>
</head>
<body>
    <h1>Pedidos de Pizzas</h1>
    <?php
    include 'conexion.php';

    $sql = "SELECT * FROM ejercicios WHERE ejercicio = 'Pedido de Pizzas'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pedidos = $stmt->fetchAll();

    if (count($pedidos) > 0) {
        echo "<pre>";
        foreach ($pedidos as $pedido) {
            echo htmlspecialchars($pedido['resultado']) . "\n";
            echo str_repeat('.', 20) . "\n";
        }
        echo "</pre>";
    } else {
        echo "<p>No se encontraron pedidos.</p>";
    }
    ?>
</body>
</html>
