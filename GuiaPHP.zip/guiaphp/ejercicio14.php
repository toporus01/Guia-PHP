<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Días de la Semana</title>
</head>
<body>
    <h1>Días de la Semana</h1>
    <?php
    include 'conexion.php';

    $diasSemana = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
    
    $primerDia = "El primer día de la semana es: " . $diasSemana[0];
    $ultimoDia = "El último día de la semana es: " . $diasSemana[count($diasSemana) - 1];
    
    echo "<p>$primerDia</p>";
    echo "<p>$ultimoDia</p>";

    // Preparar el resultado para insertar en la base de datos
    $ejercicio = 'Días de la Semana';
    $resultado = "$primerDia\n$ultimoDia";

    $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

    echo "<p>Registro insertado correctamente en la base de datos.</p>";
    ?>
</body>
</html>
