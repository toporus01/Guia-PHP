<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formulario de Estudios</title>
</head>
<body>
    <?php
    include 'conexion.php';

    // Verificar si el formulario ha sido enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_POST['nombre'];
        $estudios = $_POST['estudios'];
        $mensaje = '';

        // Mostrar el nombre y el tipo de estudios
        echo "<h2>Nombre: $nombre</h2>";
        if ($estudios == "ninguno") {
            $mensaje = "No tiene estudios.";
            echo "<p>$mensaje</p>";
        } elseif ($estudios == "primarios") {
            $mensaje = "Tiene estudios primarios.";
            echo "<p>$mensaje</p>";
        } elseif ($estudios == "secundarios") {
            $mensaje = "Tiene estudios secundarios.";
            echo "<p>$mensaje</p>";
        }

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Nivel de Estudios';
        $resultado = "Nombre: $nombre, Estudios: $mensaje";

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
        // Mostrar el formulario si no se ha enviado
        ?>
        <h2>Ingrese sus datos</h2>
        <form action="" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <br><br>
            <p>Seleccione el nivel de estudios:</p>
            <input type="radio" id="ninguno" name="estudios" value="ninguno" required>
            <label for="ninguno">No tiene estudios</label><br>
            <input type="radio" id="primarios" name="estudios" value="primarios">
            <label for="primarios">Estudios primarios</label><br>
            <input type="radio" id="secundarios" name="estudios" value="secundarios">
            <label for="secundarios">Estudios secundarios</label><br><br>
            <input type="submit" value="Enviar">
        </form>
        <?php
    }
    ?>
</body>
</html>
