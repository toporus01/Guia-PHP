<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Claves de Acceso</title>
</head>
<body>
    <h1>Claves de Acceso de Usuarios</h1>
    <?php
    include 'conexion.php';

    $claves = [
        "usuario1" => "clave1",
        "usuario2" => "clave2",
        "usuario3" => "clave3",
        "usuario4" => "clave4",
        "usuario5" => "clave5"
    ];

    // Imprimir una componente del vector
    $mensaje = "La clave de acceso de usuario2 es: " . $claves["usuario2"];
    echo "<p>$mensaje</p>";

    // Preparar el resultado para insertar en la base de datos
    $ejercicio = 'Claves de Acceso';
    $resultado = $mensaje;

    $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

    echo "<p>Registro insertado correctamente en la base de datos.</p>";
    ?>
</body>
</html>
