<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Ingresos Mensuales</title>
</head>
<body>
    <?php
    include 'conexion.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = $_POST['nombre'];
        $ingresos = $_POST['ingresos'];
        $mensaje = '';

        echo "<h2>Resultados del Ejercicio 12</h2>";
        echo "<p>Nombre: " . htmlspecialchars($nombre) . "</p>";
        echo "<p>Ingresos Mensuales: " . htmlspecialchars($ingresos) . "</p>";
        
        if ($ingresos === '>3000') {
            $mensaje = "Debe pagar impuestos a las ganancias.";
        } else {
            $mensaje = "No debe pagar impuestos a las ganancias.";
        }
        echo "<p>$mensaje</p>";

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Ingresos Mensuales';
        $resultado = "Nombre: $nombre, Ingresos: $ingresos, Mensaje: $mensaje";

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
    ?>
    <h1>Formulario de Ingresos Mensuales</h1>
    <form method="post" action="">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br><br>
        <label for="ingresos">Ingresos Mensuales:</label>
        <select id="ingresos" name="ingresos" required>
            <option value="1-1000">1-1000</option>
            <option value="1001-3000">1001-3000</option>
            <option value=">3000">>3000</option>
        </select>
        <br><br>
        <input type="submit" value="Enviar">
    </form>
    <?php
    }
    ?>
</body>
</html>
