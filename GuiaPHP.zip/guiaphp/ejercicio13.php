<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Contrato</title>
</head>
<body>
    <?php
    include 'conexion.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $contrato = $_POST['contrato'];
        
        echo "<h2>Resultados del Ejercicio 13</h2>";
        echo "<p>Contrato Modificado:</p>";
        echo "<p>" . nl2br(htmlspecialchars($contrato)) . "</p>";

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Modificación de Contrato';
        $resultado = $contrato;

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
    ?>
    <h1>Modificar Contrato</h1>
    <form method="post" action="">
        <label for="contrato">Contrato:</label><br>
        <textarea id="contrato" name="contrato" rows="10" cols="50">En la ciudad de [........], se acuerda entre la Empresa [..........] 
representada por el Sr. [..............] en su carácter de Apoderado,
con domicilio en la calle [..............] y el Sr. [..............],
futuro empleado con domicilio en [..............], celebrar el presente 
contrato a Plazo Fijo, de acuerdo a la normativa vigente de los
artículos 90,92,93,94, 95 y concordantes de la Ley de Contrato de Trabajo N° 20.744.</textarea>
        <br><br>
        <input type="submit" value="Enviar">
    </form>
    <?php
    }
    ?>
</body>
</html>
