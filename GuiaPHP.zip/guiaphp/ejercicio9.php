<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formulario de Edad</title>
</head>
<body>
    <?php
    include 'conexion.php';

    // Verificar si se enviaron datos por POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_POST['nombre'];
        $edad = $_POST['edad'];
        $mensaje = '';

        // Validar si la edad es mayor o igual a 18
        if ($edad >= 18) {
            $mensaje = "$nombre, eres mayor de edad.";
        } else {
            $mensaje = "$nombre, no eres mayor de edad.";
        }
        echo "<h2>$mensaje</h2>";

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Validación de Edad';
        $resultado = "Nombre: $nombre, Edad: $edad, Mensaje: $mensaje";

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
        // Mostrar el formulario si no se han enviado datos
        ?>
        <h2>Ingrese sus datos</h2>
        <form action="" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <br><br>
            <label for="edad">Edad:</label>
            <input type="number" id="edad" name="edad" required>
            <br><br>
            <input type="submit" value="Enviar">
        </form>
        <?php
    }
    ?>
</body>
</html>
