<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Deportes</title>
</head>
<body>
    <?php
    include 'conexion.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = $_POST['nombre'];
        $deportes = isset($_POST['deportes']) ? $_POST['deportes'] : array();
        
        echo "<h2>Resultados</h2>";
        echo "<p>Nombre: " . htmlspecialchars($nombre) . "</p>";
        echo "<p>Deportes seleccionados: " . count($deportes) . "</p>";
        
        $deportes_lista = '';
        if (!empty($deportes)) {
            echo "<ul>";
            foreach ($deportes as $deporte) {
                $deportes_lista .= htmlspecialchars($deporte) . ", ";
                echo "<li>" . htmlspecialchars($deporte) . "</li>";
            }
            echo "</ul>";
            $deportes_lista = rtrim($deportes_lista, ', ');
        } else {
            echo "<p>No se seleccionaron deportes.</p>";
            $deportes_lista = 'Ninguno';
        }

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Preferencias de Deportes';
        $resultado = "Nombre: $nombre, Deportes seleccionados: $deportes_lista";

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
    ?>
    <h1>Seleccione los deportes que practica</h1>
    <form method="post" action="">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br><br>
        <label>Deportes:</label><br>
        <input type="checkbox" id="futbol" name="deportes[]" value="Futbol">
        <label for="futbol">Futbol</label><br>
        <input type="checkbox" id="basket" name="deportes[]" value="Basket">
        <label for="basket">Basket</label><br>
        <input type="checkbox" id="tennis" name="deportes[]" value="Tennis">
        <label for="tennis">Tennis</label><br>
        <input type="checkbox" id="voley" name="deportes[]" value="Voley">
        <label for="voley">Voley</label><br><br>
        <input type="submit" value="Enviar">
    </form>
    <?php
    }
    ?>
</body>
</html>
