<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validar Claves</title>
</head>
<body>
    <?php
    include 'conexion.php';

    function validar_claves($clave1, $clave2) {
        if ($clave1 !== $clave2) {
            return "Las dos claves ingresadas son distintas.";
        } else {
            return "Las claves coinciden.";
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre_usuario = $_POST['nombre_usuario'];
        $clave1 = $_POST['clave1'];
        $clave2 = $_POST['clave2'];

        echo "<h2>Resultado de la Validación</h2>";
        echo "<p>Nombre de usuario: " . htmlspecialchars($nombre_usuario) . "</p>";
        $resultadoValidacion = validar_claves($clave1, $clave2);
        echo "<p>$resultadoValidacion</p>";

        // Preparar el resultado para insertar en la base de datos
        $ejercicio = 'Validación de Claves';
        $resultado = "Nombre de usuario: $nombre_usuario, Resultado: $resultadoValidacion";

        $sql = "INSERT INTO ejercicios (ejercicio, resultado) VALUES (:ejercicio, :resultado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['ejercicio' => $ejercicio, 'resultado' => $resultado]);

        echo "<p>Registro insertado correctamente en la base de datos.</p>";
    } else {
    ?>
    <h1>Validar Claves</h1>
    <form method="post" action="">
        <label for="nombre_usuario">Nombre de Usuario:</label>
        <input type="text" id="nombre_usuario" name="nombre_usuario" required>
        <br><br>
        <label for="clave1">Clave:</label>
        <input type="password" id="clave1" name="clave1" required>
        <br><br>
        <label for="clave2">Repetir Clave:</label>
        <input type="password" id="clave2" name="clave2" required>
        <br><br>
        <input type="submit" value="Enviar">
    </form>
    <?php
    }
    ?>
</body>
</html>
